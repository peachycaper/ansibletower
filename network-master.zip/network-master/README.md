# network
If you using AWX version with kubernetes you have to add folder collection then create file requirements.yml inside it and finally add in this file this:
---
collections:
- cisco.ios


